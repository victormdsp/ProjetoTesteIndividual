import model.LabelCollection;
import service.ResponseService;
import model.LogisticAddress;
import service.OperadorTeste;

class Main {
  public static void main(String[] args) {
    LabelCollection auxiliar = new LabelCollection();
    Envio(auxiliar);
  }

  static ResponseService Envio(LabelCollection aux){

    // Manipulação do peso do obejto para elminiar a palavra Kg para o número poder ser transformado em double;  
    String tidyVariable = aux.getWeightObject().substring(0,5);
    aux.setWeightObject(tidyVariable);

    // Manipulação tanto do CeP (Postal Code) do remetente (sender) e do destinatário (shippingDate) para eliminar o '-'; 
    LogisticAddress senderDate = aux.getSenderData();
    LogisticAddress shippingDate = aux.getShippingData();

    tidyVariable = senderDate.getPostalCode().substring(0,5)+senderDate.getPostalCode().substring(6,9);
    senderDate.setPostalCode(tidyVariable);

    tidyVariable = shippingDate.getPostalCode().substring(0,5)+shippingDate.getPostalCode().substring(6,9);
    shippingDate.setPostalCode(tidyVariable);

    // Criação da resposta (retorno do ResponseService) e do Operador que irá verificar se as informações estão corretas; 
    ResponseService saida = new ResponseService();
    OperadorTeste operator = new OperadorTeste();

    // Alterando o retorno da operação;
    saida = operator.criaEntrega(senderDate.getName(), shippingDate.getName(), senderDate.getPostalCode(), shippingDate.getPostalCode(), aux.getWeightObject());

    // Condição para verificar se o resultado que será printado está errado (400) ou correto (200);
    if(saida.getResponseString() != null){
      System.out.println(saida.getResponseString());
    }

    else{
      System.out.println(saida.getErrorMessage());
    }

    // Print do status final;
    System.out.println(saida.getStatus());

    return saida;
  }
}