Esse Projeto é uma iniciativa para testar os conhecimentos dos entrevistados para vaga de JAVA.

Requisição:
O indivíduo necessita construir um Projeto, orientado a Objeto, escrito em JAVA. O Projeto estará voltado a chamada de uma funcionalidade, tal funcionalidade deverá ser chamada pela classe MAIN.

A Funcionalidade deverá receber como parametro o Objeto LabelCollection e deverá retornar o Objeto ResponseCollection. A funcionalidade deverá chamar a classe OperadorTeste e manipular o retorno desse objeto para se adequar ao ResponseCollection.

Utilizar o projeto disponibilizado na url https://github.com/Utiyamo/ProjetoTesteIndividual.git

Objetivo:
Receber resposta positiva da classe OperadorTeste (Status 200).

Resultado:
O Projeto deverá ser publicado no github do Indivíduo e entrege ao analisador.
Assim que o código for validado o indivíduo será notificado sobre o resultado do teste.
